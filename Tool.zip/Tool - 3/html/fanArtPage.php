<?php include( "header.php" ); ?>



<?php 
$newsSummaryOnly = 0;
$numNewsPerPage = 5;
$newsForumID = 8;
$newsLinkPage = "fanArtPage.php";

include( "news.php" ); 
?>


<?php include( "footer.php" ); ?>