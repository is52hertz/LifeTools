<?php include( "header.php" ); ?>



<?php 
$newsSummaryOnly = 0;
$numNewsPerPage = 5;
$newsForumID = 4;
$newsLinkPage = "newsPage.php";

include( "news.php" ); 
?>


<?php include( "footer.php" ); ?>

