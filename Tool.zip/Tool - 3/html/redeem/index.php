<?php include( "../header.php" ); ?>


<center>
<img src=../logo558x305_border.jpg border=0 width=558 height=305>

<br>
<br>
<font size=5>Redeem a Code:</font>     

<br>
<br>


<form action="https://sites.fastspring.com/jasonrohrer/instant/onehouronelife" 
      method="post">
Code: <input type="text" name="coupon" value="" width=20>
<input type="submit" value="Redeem"><br>
</form>

<br>
<br>


<?php include( "../footer.php" ); ?>
