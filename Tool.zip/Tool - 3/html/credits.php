<?php include( "header.php" ); ?>

<br>
<br>
<br>


All code, drawings, graphics, music, sounds, and fonts by <a href="http://hcsoftware.sf.net/jason-rohrer">Jason Rohrer</a>, except for:


<br>
<br>
<br>
<br>
<br>
<br>


KISSDB server-side database by <a href="https://github.com/adamierymenko/kissdb">Adam Ierymenko</a>.<br><br><br>

The font used on the menu screens is Futura by <a href="https://en.wikipedia.org/wiki/Futura_(typeface)">Paul Renner</a>.<br><br><br>

FFT code by <a href="http://www.kurims.kyoto-u.ac.jp/~ooura/fft.html">Takuya Ooura</a>.<br><br><br>

OGG Vorbis decoder by <a href="http://nothings.org/stb_vorbis/">Sean Barrett</a>.<br><br><br>

Image output code by <a href="https://github.com/nothings/stb">Sean Barrett</a><br><br><br>

Reverb impulse response data from <a href="http://www.echothief.com/woodruff-lane/">EchoThief</a>.<br><br><br>

Spelling dictionary compiled using <a href="http://wordlist.aspell.net/">SCOWL and Friends</a> and hashed using MurmurHash2 by <a href="https://sites.google.com/site/murmurhash/">Austin Appleby</a>.<br><br><br>
     
The <a href="http://www.libsdl.org/">SDL</a> library provides cross-platform screen, sound, and user input.<br><br><br>
																			   
<a href="http://www.mingw.org/">MinGW</a> was used to build the game for Windows.<br><br><br>
    
<?php include( "footer.php" ); ?>
