
<?php
$blockRobots = 1;

global $pathToRoot;

$pathToRoot = "../";

include( "header.php" );

?>

