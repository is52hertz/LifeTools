<?php include( "header.php" ); ?>

<?php include( "foodStatsData.php" ); ?>

<?php include( "footer.php" ); ?>
