
</td>
</tr>
</table>

</td>
</tr>
</table>
</center>

<?php

$nocounter = "0";
if( isset( $_REQUEST[ "nocounter" ] ) ) {
    $nocounter = $_REQUEST[ "nocounter" ];
    }

if( ! $nocounter && ( !isSet( $blockCounter ) || ! $blockCounter ) ) {
?>

<script src="//static.getclicky.com/js" type="text/javascript"></script>
<script type="text/javascript">try{ clicky.init(101006849); }catch(e){}</script>
<noscript><p><img alt="Clicky" width="1" height="1" src="//in.getclicky.com/101006849ns.gif" /></p></noscript> 

<?php
     }
?>

     
</center>


    <table border=0 cellspacing=5 cellpadding=0 width=100%><tr>

    <td align=center width=12%>[<a href='http://onehouronelife.com'>Home</a>]</td>
    <td align=center width=12%>[<a href='https://sites.fastspring.com/jasonrohrer/instant/onehouronelife?referrer=<?php echo $referrer;?>'>Buy</a>]</td>
    
    <td align=center width=12%>[<a href="http://onehouronelife.gamepedia.com">Wiki</a>]</td>

    <td align=center width=12%>[<a href='http://onehouronelife.com/foodStats.php'>Food Stats</a>]</td>
    <td align=center width=12%>[<a href='http://onehouronelife.com/failureStats.php'>Fail Stats</a>]</td>
    <td align=center width=12%>[<a href='http://onehouronelife.com/reviewServer/server.php?action=list_polls'>Polls</a>]</td>
    <td align=center width=12%>[<a href='http://onehouronelife.com/artLogPage.php'>Artwork</a>]</td>
    <td align=center width=12%>[<a href='http://onehouronelife.com/credits.php'>Credits</a>]</td>

    
</tr></table>


</body>

</html>