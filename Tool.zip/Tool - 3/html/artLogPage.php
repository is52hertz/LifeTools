<?php include( "header.php" ); ?>



<?php 
$artSummaryOnly = 0;
$numArtPerPage = 5;

include( "artLog.php" ); 
?>


<?php include( "footer.php" ); ?>

